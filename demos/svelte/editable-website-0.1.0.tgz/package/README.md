# editable-website

Vanilla in-place editor for marketing copy. Zero runtime dependencies. Works in HTML, React, Next.js, Svelte, Angular, or any other DOM host.

The live reference is the Acme Motors demo in this repo.

## Install

```bash
npm i editable-website
```

## Bootstrap an existing app

```bash
npx editable-website
```

The CLI asks for a directory, detects HTML / React / Next / Svelte / Angular, scans for static copy, highlights fields it will not mark (images, interpolations, widgets), then writes `data-copy` and a `mount()` snippet. You still own login. Gate `PUT /api/copy`, and call `triggerCi()` at the bottom of the save handler if you want a rebuild.

## Mark copy, then mount

The text already on the page is the default. Overrides come from your API.

```html
<h1 data-copy="hero.title">The lot is open.</h1>
<p data-copy="hero.lede" data-copy-multiline>Come walk the asphalt.</p>
<editable-chip></editable-chip>
```

```ts
import { mount } from 'editable-website';

await mount({
  isAdmin: true,
  endpoints: { copy: '/api/copy' },
});
```

Outlines appear only when `isAdmin` is true **and** edit mode is on. Click a sentence to type. The floating chip is the only pencil. Escape exits.

`key` is reserved in React — use `data-copy` or `<editable-text copy-key="hero.title">`.

## Host API

Your site owns login and persistence. The package only calls:

- `GET /api/copy` → `{ copy: { "hero.title": "Sold." } }`
- `PUT /api/copy` with `{ key, value }` → the same shape, **auth-gated**

Run [examples/express](../../examples/express) locally to try that. The public demos do not connect to it.

```ts
mount({
  isAdmin,
  fetchCopy: () => fetch('/api/copy', { credentials: 'include' }).then((r) => r.json()),
  saveCopy: (key, value) =>
    fetch('/api/copy', {
      method: 'PUT',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key, value }),
    }).then((r) => r.json()),
});
```

## Framework notes

HTML: load `dist/editable-website.js`, mark tags with `data-copy`, call `EditableWebsite.mount()`.  
React: render those tags, then `mount()` in `useEffect`.  
Next.js: the server renders the marked HTML; a client host calls `mount()` and passes `isAdmin` from your session.  
Svelte: same as React, in `$effect` / `onMount`.  
Angular: add `CUSTOM_ELEMENTS_SCHEMA` and the same tags.

See the [demos](../../demos) beside this package. Persist with [examples/express](../../examples/express) — a JSON file, not our servers.
